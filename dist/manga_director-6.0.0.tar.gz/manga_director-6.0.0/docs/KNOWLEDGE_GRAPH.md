# Knowledge Graph

## v6.0 Iteration 2 foundation

`V60CreativeProductionPlatformIntelligenceService.knowledge_graph()` builds a
bounded, in-memory projection from caller-supplied provenance-bearing
knowledge references and explicit edges. Nodes cover story, character, world,
asset, production, and review evidence.

The projection is diagnostic only: it does not persist nodes or edges, load a
repository, merge records, alter source knowledge, or perform graph traversal
outside the supplied inputs. Edges that reference unknown nodes are returned
as findings for human correction.

```python
from manga_director.production import (
    KnowledgeCoreReferenceDTO,
    KnowledgeGraphEdgeDTO,
    V60CreativeProductionPlatformIntelligenceService,
)

report = V60CreativeProductionPlatformIntelligenceService().knowledge_graph(
    (
        KnowledgeCoreReferenceDTO(
            knowledge_id="story:volume-1",
            project_id="volume-1",
            kind="story",
            source_reference="story_context",
            provenance="workflow-metadata",
        ),
    ),
    (),
)
```

Node and edge identifiers are deterministic public inputs; duplicate
identifiers are rejected rather than merged or repaired.

## Compatibility

The graph is additive to v5.x. Existing Knowledge APIs, repositories,
workflows, CLI, FastAPI, MCP, and Web UI remain unchanged.
