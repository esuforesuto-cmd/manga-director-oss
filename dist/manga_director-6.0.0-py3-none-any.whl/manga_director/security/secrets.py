"""Secret retrieval boundary backed by environment variables and an optional .env file."""

from __future__ import annotations

import os
from pathlib import Path
from typing import Protocol

from manga_director.domain.exceptions import ConfigurationError


class SecretManager(Protocol):
    """Retrieve a named secret without persisting it in project configuration."""

    def get(self, name: str, *, required: bool = True) -> str | None:
        """Return a secret or raise when a required secret is unavailable."""


class EnvironmentSecretManager:
    """Read secrets from the process environment, optionally supplemented by .env."""

    def __init__(self, dotenv: Path | None = None) -> None:
        self._values = dict(os.environ)
        if dotenv is None or not dotenv.exists():
            return
        for line in dotenv.read_text(encoding="utf-8").splitlines():
            if "=" not in line or line.lstrip().startswith("#"):
                continue
            key, value = line.split("=", 1)
            self._values.setdefault(key.strip(), value.strip())

    def get(self, name: str, *, required: bool = True) -> str | None:
        value = self._values.get(name)
        if required and not value:
            raise ConfigurationError(f"Required secret '{name}' is not configured.")
        return value
