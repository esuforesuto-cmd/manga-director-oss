"""Authentication and authorization boundaries for application adapters."""

from __future__ import annotations

from typing import Protocol


class AuthenticationProvider(Protocol):
    """Resolve a principal from optional client credentials."""

    def authenticate(self, credentials: object | None = None) -> str | None:
        """Return an authenticated principal, if any."""


class AuthorizationPolicy(Protocol):
    """Decide whether a principal may perform an action on a resource."""

    def allows(
        self,
        principal: str | None,
        action: str,
        resource: str | None = None,
    ) -> bool:
        """Return whether the requested action is allowed."""


class NoAuthProvider:
    """Development-only provider that exposes an anonymous principal."""

    def authenticate(self, credentials: object | None = None) -> str | None:
        del credentials
        return "anonymous"


class AllowAllPolicy:
    """Development-only policy that permits every action."""

    def allows(
        self,
        principal: str | None,
        action: str,
        resource: str | None = None,
    ) -> bool:
        del principal, action, resource
        return True
