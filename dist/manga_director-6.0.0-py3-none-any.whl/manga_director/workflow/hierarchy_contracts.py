"""Typed contexts and results for Project → Chapter → Page orchestration."""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, ConfigDict, Field

from manga_director.domain.events import WorkflowEvent
from manga_director.domain.project import Chapter, Page, Project
from manga_director.workflow.contracts import WorkflowContext


class ProjectContext(BaseModel):
    """Persistable Project-level workflow view with its current chapter/page position."""

    model_config = ConfigDict(frozen=True)

    project: Project
    chapters: list[Chapter] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)
    history: list[dict[str, Any]] = Field(default_factory=list)
    current_chapter: str | None = None
    current_page: int | None = None


class ChapterContext(BaseModel):
    """Ordered Chapter-level workflow view over persisted page aggregates."""

    model_config = ConfigDict(frozen=True)

    chapter: Chapter
    pages: list[Page] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)
    history: list[dict[str, Any]] = Field(default_factory=list)
    current_page: int | None = None


class ChapterWorkflowResult(BaseModel):
    """Outcome of scheduling and executing at most one page in a chapter."""

    model_config = ConfigDict(frozen=True)

    context: ChapterContext
    page_context: WorkflowContext | None = None
    completed: bool
    events: list[WorkflowEvent] = Field(default_factory=list)
    messages: list[str] = Field(default_factory=list)


class ProjectWorkflowResult(BaseModel):
    """Outcome of a Project-level operation with optional child execution detail."""

    model_config = ConfigDict(frozen=True)

    context: ProjectContext
    chapter_result: ChapterWorkflowResult | None = None
    events: list[WorkflowEvent] = Field(default_factory=list)
    messages: list[str] = Field(default_factory=list)
