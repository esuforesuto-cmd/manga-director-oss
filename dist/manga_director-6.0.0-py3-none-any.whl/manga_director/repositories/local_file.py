from __future__ import annotations

import json
from builtins import list as builtin_list
from pathlib import Path
from typing import Any

from manga_director.domain.exceptions import ProjectNotFoundError
from manga_director.domain.project import Page, Project
from manga_director.observability.repository import RepositoryMetrics
from manga_director.repositories.protocols import ProjectRepository
from manga_director.repositories.queries import ProjectMetadata, page_history_slice
from manga_director.repositories.serializer import ProjectSerializer, SerializationFormat
from manga_director.repositories.validator import ProjectValidator


class LocalFileRepository(ProjectRepository):
    """Repository that stores one validated Project document below projects/."""

    def __init__(
        self,
        root: Path,
        *,
        format: SerializationFormat = "json",
        serializer: ProjectSerializer | None = None,
        validator: ProjectValidator | None = None,
        metrics: RepositoryMetrics | None = None,
    ) -> None:
        self._root = root / "projects"
        self._serializer = serializer or ProjectSerializer(format)
        self._validator = validator or ProjectValidator()
        self.metrics = metrics or RepositoryMetrics()

    @property
    def _suffix(self) -> str:
        return ".json" if self._serializer.format == "json" else ".yaml"

    def _path(self, project_id: str) -> Path:
        return self._root / f"{project_id}{self._suffix}"

    @property
    def _index_path(self) -> Path:
        return self._root / "_metadata_index.json"

    def _page_directory(self, project_id: str) -> Path:
        """Return the private page-document directory for selective reads."""

        return self._root / "_pages" / project_id

    def _page_path(self, project_id: str, page_number: int) -> Path:
        return self._page_directory(project_id) / f"{page_number}.json"

    def load(self, project_id: str) -> Project:
        return self.metrics.measure("load", lambda: self._load(project_id))

    def _load(self, project_id: str) -> Project:
        path = self._path(project_id)
        try:
            return self._serializer.loads(path.read_text(encoding="utf-8"))
        except FileNotFoundError as exc:
            raise ProjectNotFoundError(f"Project '{project_id}' does not exist.") from exc

    def save(self, project: Project) -> None:
        self.metrics.measure("save", lambda: self._save(project))

    def _save(self, project: Project) -> None:
        self._validator.validate(project)
        path = self._path(project.id)
        path.parent.mkdir(parents=True, exist_ok=True)
        serialized = self._serializer.dumps(project)
        try:
            unchanged = path.read_text(encoding="utf-8") == serialized
        except FileNotFoundError:
            unchanged = False
        if not unchanged:
            temporary = path.with_suffix(f"{path.suffix}.tmp")
            temporary.write_text(serialized, encoding="utf-8")
            temporary.replace(path)
        index = self._read_index()
        metadata = self._metadata(project)
        if index.get(project.id) != metadata:
            index[project.id] = metadata
            self._write_index(index)
        self._save_page_documents(project)

    def exists(self, project_id: str) -> bool:
        return self.metrics.measure("exists", lambda: self._path(project_id).exists())

    def delete(self, project_id: str) -> None:
        self.metrics.measure("delete", lambda: self._delete(project_id))

    def _delete(self, project_id: str) -> None:
        path = self._path(project_id)
        try:
            path.unlink()
        except FileNotFoundError as exc:
            raise ProjectNotFoundError(f"Project '{project_id}' does not exist.") from exc
        index = self._read_index()
        if project_id in index:
            del index[project_id]
            self._write_index(index)
        page_directory = self._page_directory(project_id)
        if page_directory.exists():
            for page_path in page_directory.glob("*.json"):
                page_path.unlink()
            page_directory.rmdir()

    def list(self) -> list[Project]:
        return self.metrics.measure(
            "list",
            lambda: [
                self._serializer.loads(path.read_text(encoding="utf-8"))
                for path in self._project_paths()
            ],
        )

    def list_metadata(
        self, *, offset: int = 0, limit: int | None = None
    ) -> builtin_list[ProjectMetadata]:
        return self.metrics.measure("list_metadata", lambda: self._list_metadata(offset, limit))

    def _list_metadata(self, offset: int, limit: int | None) -> builtin_list[ProjectMetadata]:
        _validate_window(offset, limit)
        index = self._read_index()
        records = [index[key] for key in sorted(index)]
        return records[offset : None if limit is None else offset + limit]

    def load_page(self, project_id: str, page_number: int) -> Page:
        return self.metrics.measure("load_page", lambda: self._load_page(project_id, page_number))

    def _load_page(self, project_id: str, page_number: int) -> Page:
        try:
            return Page.model_validate_json(
                self._page_path(project_id, page_number).read_text(encoding="utf-8")
            )
        except FileNotFoundError:
            # Projects written before selective page documents remain readable.
            return self._load(project_id).page(page_number)

    def load_history(
        self,
        project_id: str,
        page_number: int,
        *,
        offset: int = 0,
        limit: int | None = None,
    ) -> builtin_list[dict[str, Any]]:
        return self.metrics.measure(
            "load_history",
            lambda: page_history_slice(
                self._load_page(project_id, page_number).history, offset=offset, limit=limit
            ),
        )

    def _save_page_documents(self, project: Project) -> None:
        """Persist only changed page documents so page reads do not deserialize an aggregate."""

        page_directory = self._page_directory(project.id)
        page_directory.mkdir(parents=True, exist_ok=True)
        page_numbers = {page.page_number for page in project.pages}
        for page_path in page_directory.glob("*.json"):
            if page_path.stem.isdigit() and int(page_path.stem) not in page_numbers:
                page_path.unlink()
        for page in project.pages:
            path = self._page_path(project.id, page.page_number)
            serialized = page.model_dump_json()
            try:
                if path.read_text(encoding="utf-8") == serialized:
                    continue
            except FileNotFoundError:
                pass
            temporary = path.with_suffix(".json.tmp")
            temporary.write_text(serialized, encoding="utf-8")
            temporary.replace(path)

    def _project_paths(self) -> builtin_list[Path]:
        return [
            path
            for path in sorted(self._root.glob(f"*{self._suffix}"))
            if path.name != self._index_path.name
        ]

    def _read_index(self) -> dict[str, ProjectMetadata]:
        try:
            raw = json.loads(self._index_path.read_text(encoding="utf-8"))
            return {key: ProjectMetadata.model_validate(value) for key, value in raw.items()}
        except FileNotFoundError:
            index = {
                project.id: self._metadata(project)
                for project in (
                    self._serializer.loads(path.read_text(encoding="utf-8"))
                    for path in self._project_paths()
                )
            }
            if index:
                self._write_index(index)
            return index

    def _write_index(self, index: dict[str, ProjectMetadata]) -> None:
        self._root.mkdir(parents=True, exist_ok=True)
        serialized = json.dumps({key: value.model_dump(mode="json") for key, value in index.items()})
        try:
            if self._index_path.read_text(encoding="utf-8") == serialized:
                return
        except FileNotFoundError:
            pass
        temporary = self._index_path.with_suffix(".json.tmp")
        temporary.write_text(serialized, encoding="utf-8")
        temporary.replace(self._index_path)

    @staticmethod
    def _metadata(project: Project) -> ProjectMetadata:
        return ProjectMetadata(
            id=project.id,
            title=project.title,
            page_count=len(project.pages),
            chapter_count=len(project.chapters),
            updated_at=project.updated_at,
        )


def _validate_window(offset: int, limit: int | None) -> None:
    if offset < 0 or (limit is not None and limit < 0):
        raise ValueError("offset and limit must be non-negative")
