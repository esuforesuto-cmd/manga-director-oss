"""Read-only v5.7 Production Workspace v2 projections.

The module composes the v5.7 Foundation with caller-supplied resource and
template evidence. It validates one existing Page only and never allocates a
resource, persists a session, resumes work, changes workflow state, or writes
to a repository. The domain StateMachine remains authoritative.
"""

from __future__ import annotations

from typing import Literal

from pydantic import Field

from manga_director.domain.state_machine import PageState, StateMachine
from manga_director.production.director import DirectorModel
from manga_director.production.v5_7_platform_foundation import (
    AssetManagerReport,
    PluginRuntimeSource,
    ProjectManagerReport,
    V57ProductionPlatformFoundationService,
    WorkspaceManagerReport,
)
from manga_director.workflow.contracts import WorkflowContext


class AssetRegistryEntryDTO(DirectorModel):
    asset_id: str
    project_id: str
    page_reference: str
    source_key: str
    source_kind: Literal["artifact", "metadata"]
    lifecycle_state: Literal["observed"] = "observed"
    registry_written: Literal[False] = False


class AssetRegistryReport(DirectorModel):
    entries: tuple[AssetRegistryEntryDTO, ...] = ()
    unique_source_keys: tuple[str, ...] = ()
    lifecycle_valid: bool
    registry_persisted: Literal[False] = False
    repository_mutated: Literal[False] = False
    planning_only: Literal[True] = True


class ProjectWorkspaceDTO(DirectorModel):
    workspace_id: str
    project_id: str
    page_reference: str
    workflow_state: PageState
    page_count: Literal[1] = 1
    workspace_consistent: bool
    workspace_persisted: Literal[False] = False
    project_mutated: Literal[False] = False


class ProjectWorkspaceReport(DirectorModel):
    workspace: ProjectWorkspaceDTO
    asset_reference_count: int = Field(default=0, ge=0)
    workflow_state_owned_by: Literal["StateMachine"] = "StateMachine"
    planning_only: Literal[True] = True


class WorkflowStateManagerDTO(DirectorModel):
    project_id: str
    page_reference: str
    current_state: PageState
    next_command: str | None = None
    storyboard_persisted: bool
    quality_review_completed: bool
    state_changed: Literal[False] = False


class WorkflowStateValidationReport(DirectorModel):
    state: WorkflowStateManagerDTO
    valid: bool
    findings: tuple[str, ...] = ()
    state_machine_authoritative: Literal[True] = True
    planning_only: Literal[True] = True


class ResourceAllocationDTO(DirectorModel):
    resource_id: str
    project_id: str
    page_reference: str
    owner: str
    requested_units: int = Field(default=1, ge=0)
    available_units: int = Field(default=1, ge=0)
    allocation_performed: Literal[False] = False


class ResourceManagerReport(DirectorModel):
    allocations: tuple[ResourceAllocationDTO, ...] = ()
    allocation_valid: bool
    insufficient_resource_ids: tuple[str, ...] = ()
    allocation_mutated: Literal[False] = False
    planning_only: Literal[True] = True


class ProductionTemplateDTO(DirectorModel):
    template_id: str
    page_reference: str
    required_evidence: tuple[str, ...] = ()
    template_loaded: Literal[False] = False
    template_applied: Literal[False] = False


class TemplateRegistryReport(DirectorModel):
    templates: tuple[ProductionTemplateDTO, ...] = ()
    compatible: bool
    missing_evidence: tuple[str, ...] = ()
    registry_mutated: Literal[False] = False
    planning_only: Literal[True] = True


class V57ProductionSessionDTO(DirectorModel):
    session_id: str
    project_id: str
    page_reference: str
    current_state: PageState
    checkpoint_evidence_available: bool
    recovery_eligible: bool
    session_created: Literal[False] = False
    session_persisted: Literal[False] = False
    resumed: Literal[False] = False


class SessionRecoveryReport(DirectorModel):
    session: V57ProductionSessionDTO
    missing_recovery_evidence: tuple[str, ...] = ()
    recovery_performed: Literal[False] = False
    workflow_mutated: Literal[False] = False
    planning_only: Literal[True] = True


class ProductionWorkspaceV2Report(DirectorModel):
    assets: AssetRegistryReport
    workspace: ProjectWorkspaceReport
    workflow: WorkflowStateValidationReport
    resources: ResourceManagerReport
    templates: TemplateRegistryReport
    session: SessionRecoveryReport
    automatic_action_taken: Literal[False] = False
    planning_only: Literal[True] = True


class V57ProductionWorkspaceService:
    """Build one-page Production Workspace v2 diagnostics without side effects."""

    def __init__(self, plugin_source: PluginRuntimeSource | None = None) -> None:
        self._foundation = V57ProductionPlatformFoundationService(plugin_source)

    def asset_registry(self, project_id: str, context: WorkflowContext) -> AssetRegistryReport:
        assets = self._foundation.assets(project_id, context)
        entries = tuple(
            AssetRegistryEntryDTO(
                asset_id=asset.asset_id,
                project_id=asset.project_id,
                page_reference=asset.page_reference,
                source_key=asset.source_key,
                source_kind=asset.source_kind,
            )
            for asset in assets.assets
        )
        return AssetRegistryReport(
            entries=entries,
            unique_source_keys=tuple(sorted({entry.source_key for entry in entries})),
            lifecycle_valid=all(entry.lifecycle_state == "observed" for entry in entries),
        )

    def project_workspace(
        self, project_id: str, context: WorkflowContext
    ) -> ProjectWorkspaceReport:
        workspace = self._foundation.workspace(project_id, context)
        project = self._foundation.project(project_id, context)
        assets = self._foundation.assets(project_id, context)
        return _project_workspace_report(workspace, project, assets)

    def workflow_state(
        self, project_id: str, context: WorkflowContext
    ) -> WorkflowStateValidationReport:
        workspace = self._foundation.workspace(project_id, context)
        project = self._foundation.project(project_id, context)
        current_state = context.state
        next_command = None if current_state is PageState.APPROVED else StateMachine().next_command(
            current_state
        )
        findings = _workflow_findings(project)
        return WorkflowStateValidationReport(
            state=WorkflowStateManagerDTO(
                project_id=project_id,
                page_reference=workspace.workspace.page_reference,
                current_state=current_state,
                next_command=next_command,
                storyboard_persisted=project.project.storyboard_persisted,
                quality_review_completed=project.project.quality_review_completed,
            ),
            valid=not findings,
            findings=findings,
        )

    def resources(
        self,
        project_id: str,
        context: WorkflowContext,
        allocations: tuple[ResourceAllocationDTO, ...] = (),
    ) -> ResourceManagerReport:
        page_reference = self._foundation.workspace(project_id, context).workspace.page_reference
        observed = allocations or (
            ResourceAllocationDTO(
                resource_id=f"human-owner:{project_id}:{page_reference}",
                project_id=project_id,
                page_reference=page_reference,
                owner="human-owner",
            ),
        )
        invalid_scope = tuple(
            allocation.resource_id
            for allocation in observed
            if allocation.project_id != project_id or allocation.page_reference != page_reference
        )
        insufficient = tuple(
            allocation.resource_id
            for allocation in observed
            if allocation.available_units < allocation.requested_units
        )
        return ResourceManagerReport(
            allocations=observed,
            allocation_valid=not invalid_scope and not insufficient,
            insufficient_resource_ids=tuple(sorted({*invalid_scope, *insufficient})),
        )

    def templates(
        self,
        project_id: str,
        context: WorkflowContext,
        templates: tuple[ProductionTemplateDTO, ...] = (),
    ) -> TemplateRegistryReport:
        page_reference = self._foundation.workspace(project_id, context).workspace.page_reference
        evidence = {*(str(key) for key in context.artifacts), *(str(key) for key in context.metadata)}
        missing = tuple(
            sorted(
                {
                    evidence_key
                    for template in templates
                    for evidence_key in template.required_evidence
                    if evidence_key not in evidence
                }
            )
        )
        compatible = not missing and all(
            template.page_reference == page_reference
            and not template.template_loaded
            and not template.template_applied
            for template in templates
        )
        return TemplateRegistryReport(
            templates=templates,
            compatible=compatible,
            missing_evidence=missing,
        )

    def production_session(
        self, project_id: str, context: WorkflowContext
    ) -> SessionRecoveryReport:
        workspace = self._foundation.workspace(project_id, context)
        project = self._foundation.project(project_id, context)
        checkpoint_available = bool(context.artifacts) or bool(context.metadata.get("workflow_history"))
        missing: list[str] = []
        if not checkpoint_available:
            missing.append("checkpoint evidence is required")
        if current_state_requires_storyboard(context.state) and not project.project.storyboard_persisted:
            missing.append("persisted storyboard is required")
        if context.state is PageState.APPROVED and not project.project.quality_review_completed:
            missing.append("completed quality review is required")
        return SessionRecoveryReport(
            session=V57ProductionSessionDTO(
                session_id=f"production-session:{project_id}:{workspace.workspace.page_reference}",
                project_id=project_id,
                page_reference=workspace.workspace.page_reference,
                current_state=context.state,
                checkpoint_evidence_available=checkpoint_available,
                recovery_eligible=not missing,
            ),
            missing_recovery_evidence=tuple(missing),
        )

    def production_workspace(
        self,
        project_id: str,
        context: WorkflowContext,
        allocations: tuple[ResourceAllocationDTO, ...] = (),
        templates: tuple[ProductionTemplateDTO, ...] = (),
    ) -> ProductionWorkspaceV2Report:
        return ProductionWorkspaceV2Report(
            assets=self.asset_registry(project_id, context),
            workspace=self.project_workspace(project_id, context),
            workflow=self.workflow_state(project_id, context),
            resources=self.resources(project_id, context, allocations),
            templates=self.templates(project_id, context, templates),
            session=self.production_session(project_id, context),
        )


def _project_workspace_report(
    workspace: WorkspaceManagerReport,
    project: ProjectManagerReport,
    assets: AssetManagerReport,
) -> ProjectWorkspaceReport:
    consistent = (
        workspace.workspace.project_id == project.project.project_id
        and workspace.workspace.page_reference == project.project.page_reference
        and workspace.workspace.current_state == project.project.current_state
    )
    return ProjectWorkspaceReport(
        workspace=ProjectWorkspaceDTO(
            workspace_id=workspace.workspace.workspace_id,
            project_id=project.project.project_id,
            page_reference=project.project.page_reference,
            workflow_state=project.project.current_state,
            workspace_consistent=consistent,
        ),
        asset_reference_count=assets.summary.observed_asset_count,
    )


def _workflow_findings(project: ProjectManagerReport) -> tuple[str, ...]:
    findings: list[str] = []
    state = project.project.current_state
    if current_state_requires_storyboard(state) and not project.project.storyboard_persisted:
        findings.append("persisted storyboard is required")
    if state is PageState.APPROVED and not project.project.quality_review_completed:
        findings.append("completed quality review is required")
    return tuple(findings)


def current_state_requires_storyboard(state: PageState) -> bool:
    return state in (PageState.GENERATED, PageState.QUALITY_CHECKED, PageState.APPROVED)
