"""Read-only v6.0 Creative Production Platform foundation DTOs.

This Application-layer module composes existing v5.7 one-page evidence with
caller-supplied cross-project references. It does not execute AI work, mutate
projects or workspaces, persist knowledge, alter collaboration, or bypass the
StateMachine.
"""

from __future__ import annotations

from collections.abc import Iterable
from typing import Literal

from pydantic import Field

from manga_director.domain.state_machine import PageState
from manga_director.production.director import DirectorModel
from manga_director.production.v5_7_platform_foundation import (
    ProductionPlatformFoundationReport,
    V57ProductionPlatformFoundationService,
)
from manga_director.workflow.contracts import WorkflowContext


class ProductionCoreDTO(DirectorModel):
    platform_id: str
    project_id: str
    page_reference: str
    current_state: PageState
    page_count: Literal[1] = 1
    production_executed: Literal[False] = False
    workflow_mutated: Literal[False] = False


class ProductionCoreReport(DirectorModel):
    production: ProductionCoreDTO
    v5_7_evidence: ProductionPlatformFoundationReport
    state_machine_authoritative: Literal[True] = True
    planning_only: Literal[True] = True


class ProjectHubReferenceDTO(DirectorModel):
    project_id: str
    title: str
    workspace_ids: tuple[str, ...] = ()
    project_loaded: Literal[False] = False
    project_persisted: Literal[False] = False


class ProjectHubReport(DirectorModel):
    projects: tuple[ProjectHubReferenceDTO, ...] = ()
    project_count: int = Field(default=0, ge=0)
    cross_project_workflow_executed: Literal[False] = False
    planning_only: Literal[True] = True


class WorkspaceHubReferenceDTO(DirectorModel):
    workspace_id: str
    project_id: str
    label: str
    page_reference: str | None = None
    workspace_created: Literal[False] = False
    workspace_persisted: Literal[False] = False


class WorkspaceHubReport(DirectorModel):
    workspaces: tuple[WorkspaceHubReferenceDTO, ...] = ()
    workspace_count: int = Field(default=0, ge=0)
    multi_workspace_ready: bool
    workspace_mutated: Literal[False] = False
    planning_only: Literal[True] = True


class KnowledgeCoreReferenceDTO(DirectorModel):
    knowledge_id: str
    project_id: str
    kind: Literal["story", "character", "world", "asset", "production", "review"]
    source_reference: str
    provenance: str
    knowledge_persisted: Literal[False] = False


class KnowledgeCoreReport(DirectorModel):
    references: tuple[KnowledgeCoreReferenceDTO, ...] = ()
    knowledge_count: int = Field(default=0, ge=0)
    graph_built: Literal[False] = False
    source_repository_changed: Literal[False] = False
    analysis_only: Literal[True] = True


class AIOrchestratorFoundationDTO(DirectorModel):
    orchestration_id: str
    project_id: str
    page_reference: str
    capability_references: tuple[str, ...] = ()
    evidence_references: tuple[str, ...] = ()
    human_approval_required: Literal[True] = True
    plan_generated: Literal[False] = False
    execution_dispatched: Literal[False] = False
    workflow_mutated: Literal[False] = False


class AIOrchestratorFoundationReport(DirectorModel):
    orchestrator: AIOrchestratorFoundationDTO
    recommendation: str
    planning_only: Literal[True] = True


class CollaborationAssignmentDTO(DirectorModel):
    assignment_id: str
    project_id: str
    workspace_id: str
    role: Literal["director", "editor", "writer", "artist", "reviewer", "operator"]
    assignee_reference: str
    review_required: Literal[True] = True
    assignment_created: Literal[False] = False
    approval_granted: Literal[False] = False


class CollaborationCoreReport(DirectorModel):
    assignments: tuple[CollaborationAssignmentDTO, ...] = ()
    assignment_count: int = Field(default=0, ge=0)
    collaboration_executed: Literal[False] = False
    planning_only: Literal[True] = True


class ServiceRegistryEntryDTO(DirectorModel):
    service_id: str
    capability: str
    owner: Literal[
        "platform_core",
        "workspace_engine",
        "project_manager",
        "knowledge_engine",
        "ai_orchestrator",
        "collaboration_engine",
    ]
    compatibility: Literal["v5_additive", "v6_foundation"]
    service_registered: Literal[False] = False


class ServiceRegistryReport(DirectorModel):
    services: tuple[ServiceRegistryEntryDTO, ...] = ()
    service_count: int = Field(default=0, ge=0)
    registry_mutated: Literal[False] = False
    planning_only: Literal[True] = True


class CreativeProductionPlatformCoreReport(DirectorModel):
    production: ProductionCoreReport
    projects: ProjectHubReport
    workspaces: WorkspaceHubReport
    knowledge: KnowledgeCoreReport
    ai_orchestrator: AIOrchestratorFoundationReport
    collaboration: CollaborationCoreReport
    services: ServiceRegistryReport
    v5_compatibility_preserved: Literal[True] = True
    automatic_action_taken: Literal[False] = False
    planning_only: Literal[True] = True


class V60CreativeProductionPlatformFoundationService:
    """Compose v6.0 platform foundation reports from v5.7 evidence only."""

    def __init__(self) -> None:
        self._v57 = V57ProductionPlatformFoundationService()

    def production_core(self, project_id: str, context: WorkflowContext) -> ProductionCoreReport:
        evidence = self._v57.foundation(project_id, context)
        project = evidence.project.project
        return ProductionCoreReport(
            production=ProductionCoreDTO(
                platform_id=f"creative-production-platform:{project_id}",
                project_id=project_id,
                page_reference=project.page_reference,
                current_state=project.current_state,
            ),
            v5_7_evidence=evidence,
        )

    def project_hub(
        self, projects: tuple[ProjectHubReferenceDTO, ...] = ()
    ) -> ProjectHubReport:
        _require_unique((project.project_id for project in projects), "project_id")
        ordered = tuple(sorted(projects, key=lambda project: project.project_id))
        return ProjectHubReport(projects=ordered, project_count=len(ordered))

    def workspace_hub(
        self, workspaces: tuple[WorkspaceHubReferenceDTO, ...] = ()
    ) -> WorkspaceHubReport:
        _require_unique((workspace.workspace_id for workspace in workspaces), "workspace_id")
        ordered = tuple(sorted(workspaces, key=lambda workspace: workspace.workspace_id))
        return WorkspaceHubReport(
            workspaces=ordered,
            workspace_count=len(ordered),
            multi_workspace_ready=len(ordered) > 1,
        )

    def knowledge_core(
        self, references: tuple[KnowledgeCoreReferenceDTO, ...] = ()
    ) -> KnowledgeCoreReport:
        _require_unique((reference.knowledge_id for reference in references), "knowledge_id")
        ordered = tuple(sorted(references, key=lambda reference: reference.knowledge_id))
        return KnowledgeCoreReport(references=ordered, knowledge_count=len(ordered))

    def ai_orchestrator(self, project_id: str, context: WorkflowContext) -> AIOrchestratorFoundationReport:
        production = self.production_core(project_id, context).production
        evidence_references = tuple(
            key
            for key in ("story_context", "character_context", "world_context", "timeline_context")
            if key in context.metadata
        )
        return AIOrchestratorFoundationReport(
            orchestrator=AIOrchestratorFoundationDTO(
                orchestration_id=f"ai-orchestrator:{project_id}:{production.page_reference}",
                project_id=project_id,
                page_reference=production.page_reference,
                capability_references=("planning", "review-support", "context-reference"),
                evidence_references=evidence_references,
            ),
            recommendation="Use existing StateMachine and human-review boundaries for any next step.",
        )

    def collaboration_core(
        self, assignments: tuple[CollaborationAssignmentDTO, ...] = ()
    ) -> CollaborationCoreReport:
        _require_unique((assignment.assignment_id for assignment in assignments), "assignment_id")
        ordered = tuple(sorted(assignments, key=lambda assignment: assignment.assignment_id))
        return CollaborationCoreReport(assignments=ordered, assignment_count=len(ordered))

    def service_registry(
        self, services: tuple[ServiceRegistryEntryDTO, ...] = ()
    ) -> ServiceRegistryReport:
        _require_unique((service.service_id for service in services), "service_id")
        ordered = tuple(sorted(services, key=lambda service: service.service_id))
        return ServiceRegistryReport(services=ordered, service_count=len(ordered))

    def foundation(
        self,
        project_id: str,
        context: WorkflowContext,
        *,
        projects: tuple[ProjectHubReferenceDTO, ...] = (),
        workspaces: tuple[WorkspaceHubReferenceDTO, ...] = (),
        knowledge: tuple[KnowledgeCoreReferenceDTO, ...] = (),
        assignments: tuple[CollaborationAssignmentDTO, ...] = (),
        services: tuple[ServiceRegistryEntryDTO, ...] = (),
    ) -> CreativeProductionPlatformCoreReport:
        return CreativeProductionPlatformCoreReport(
            production=self.production_core(project_id, context),
            projects=self.project_hub(projects),
            workspaces=self.workspace_hub(workspaces),
            knowledge=self.knowledge_core(knowledge),
            ai_orchestrator=self.ai_orchestrator(project_id, context),
            collaboration=self.collaboration_core(assignments),
            services=self.service_registry(services),
        )


def _require_unique(values: Iterable[str], field_name: str) -> None:
    items = tuple(values)
    if len(items) != len(set(items)):
        raise ValueError(f"{field_name} values must be unique")
