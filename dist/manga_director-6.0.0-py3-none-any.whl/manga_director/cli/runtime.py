from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from manga_director.adapters.factory import ImageGeneratorFactory
from manga_director.adapters.llm_factory import LLMFactory
from manga_director.adapters.runtime import ImageBackendRuntime, LLMProviderRuntime
from manga_director.agents.registry import primary_agents, support_agents
from manga_director.cli.config import AppConfig
from manga_director.cli.logging import configure_logging
from manga_director.domain.state_machine import StateMachine
from manga_director.events import MemoryEventBus
from manga_director.plugins import (
    PluginManager,
    PluginRegistry,
    apply_agent_plugins,
    apply_image_generator_plugins,
    apply_llm_plugins,
)
from manga_director.prompting import PromptPipeline, PromptTemplateLoader
from manga_director.repositories import ProjectLoader
from manga_director.workflow import (
    BatchWorkflowEngine,
    ChapterWorkflowEngine,
    PageNumberWorkflowScheduler,
    ProjectWorkflowEngine,
    WorkflowCoordinator,
    WorkflowEngine,
    WorkflowWorker,
)


@dataclass(frozen=True)
class CliRuntime:
    config: AppConfig
    engine: WorkflowEngine
    loader: ProjectLoader
    plugins: PluginManager
    coordinator: WorkflowCoordinator
    batch: BatchWorkflowEngine
    prompt_directory: Path | None
    providers: LLMProviderRuntime
    backends: ImageBackendRuntime


def build_runtime(config: AppConfig, config_directory: Path) -> CliRuntime:
    """Composition root. CLI command handlers receive only this Engine-facing runtime."""
    logger = configure_logging(config.log_level)
    plugin_directory = config.plugin_directory
    if not plugin_directory.is_absolute():
        plugin_directory = config_directory / plugin_directory
    plugins = PluginManager(plugin_directory, PluginRegistry())
    plugins.load_enabled()
    apply_image_generator_plugins(plugins.registry)
    apply_llm_plugins(plugins.registry)
    generator = ImageGeneratorFactory.create(config.default_image_generator)
    llm_provider = LLMFactory.create(config.default_llm_provider)
    prompt_directory = config.prompt_directory
    if prompt_directory is not None and not prompt_directory.is_absolute():
        prompt_directory = config_directory / prompt_directory
    prompt_pipeline = PromptPipeline(
        template_loader=PromptTemplateLoader(prompt_directory),
        default_template=config.default_prompt_template,
        optimizer_enabled=config.optimizer_enabled,
        validation_enabled=config.validation_enabled,
    )
    primary, support = apply_agent_plugins(
        plugins.registry,
        primary_agents(generator, prompt_directory, llm_provider, prompt_pipeline),
        support_agents(llm_provider, prompt_directory),
    )
    event_bus = MemoryEventBus()
    engine = WorkflowEngine(
        state_machine=StateMachine(),
        event_bus=event_bus,
        agents=primary,
        support_agents=support,
    )
    loader = ProjectLoader.from_settings(
        config.repository.driver,
        config.repository.root,
        config.repository.format,
        config_directory,
        config.database_provider,
        config.database_url,
    )
    project_engine = ProjectWorkflowEngine(loader.repository, event_bus)
    coordinator = WorkflowCoordinator(
        project_engine,
        ChapterWorkflowEngine(loader.repository, event_bus, PageNumberWorkflowScheduler()),
        engine,
        loader,
    )
    batch = BatchWorkflowEngine(
        loader.repository,
        loader,
        WorkflowWorker(engine),
        event_bus,
        project_engine=project_engine,
    )
    logger.debug("CLI runtime initialized")
    return CliRuntime(
        config=config,
        engine=engine,
        plugins=plugins,
        loader=loader,
        coordinator=coordinator,
        batch=batch,
        prompt_directory=prompt_directory,
        providers=LLMProviderRuntime(),
        backends=ImageBackendRuntime(),
    )
